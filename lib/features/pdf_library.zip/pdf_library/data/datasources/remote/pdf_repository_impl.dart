import 'package:lawyerup_android/features/pdf_library/data/datasources/remote/pdf_remote_datasource.dart';
import '../../../domain/entities/pdf_entity.dart';
import '../../../domain/repositories/pdf_repository.dart';

class PdfRepositoryImpl implements PdfRepository {
  final PdfRemoteDataSource remoteDataSource;

  PdfRepositoryImpl(this.remoteDataSource);

  @override
  Future<List<PdfEntity>> getAllPdfs() async {
    return await remoteDataSource.getAllPdfs();
  }
}
