import 'package:flutter/material.dart';
import '../widgets/news_article_card.dart';
import '../pages/news_preview_page.dart';
import '../../data/models/news_model.dart';

class NewsPage extends StatelessWidget {
  final List<NewsModel> newsList;

  const NewsPage({super.key, required this.newsList});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E2B3A),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "News & Article",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          final news = newsList[index];
          return NewsCard(
            date: news.date,
            title: news.title,
            author: news.author,
            description: news.summary,
            imagePath: news.fullImageUrl,
            likes: news.likes,
            dislikes: news.dislikes,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => NewsPreviewPage(news: news),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
