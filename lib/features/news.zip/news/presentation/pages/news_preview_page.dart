import 'package:flutter/material.dart';
import '../../data/models/news_model.dart';

class NewsPreviewPage extends StatelessWidget {
  final NewsModel news;

  const NewsPreviewPage({super.key, required this.news});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E2B3A),
        elevation: 0,
        title: const Text("News Preview", style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            news.date,
            style: const TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 6),
          Text(
            news.title,
            style: const TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "By ${news.author}",
            style: const TextStyle(
              fontFamily: 'Lora',
              fontSize: 13,
              fontStyle: FontStyle.italic,
              color: Colors.black54,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            news.summary,
            style: const TextStyle(fontFamily: 'Lora', fontSize: 16, height: 1.6),
          ),
          const SizedBox(height: 16),
          if (news.fullImageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(news.fullImageUrl),
            ),
        ],
      ),
    );
  }
}
