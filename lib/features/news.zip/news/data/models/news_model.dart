import '../../../../app/constant/api_endpoints.dart';
import '../../domain/entities/news.dart';

class NewsModel extends News {
  NewsModel({
    required super.id,
    required super.title,
    required super.summary,
    required super.date,
    required super.image,
    required super.likes,
    required super.dislikes,
    required super.comments,
    required super.author, // ✅ ADD THIS
  });

  factory NewsModel.fromJson(Map<String, dynamic> json) {
    return NewsModel(
      id: json['_id'],
      title: json['title'] ?? '',
      summary: json['summary'] ?? '',
      date: json['date'] ?? '',
      image: json['image'] ?? '',
      likes: json['likes'] ?? 0,
      dislikes: json['dislikes'] ?? 0,
      author: json['author'] ?? '', // ✅ ADD THIS
      comments: (json['comments'] as List<dynamic>?)
          ?.map((c) => c['text'] as String)
          .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'title': title,
    'summary': summary,
    'date': date,
    'image': image,
    'likes': likes,
    'dislikes': dislikes,
    'author': author, // ✅ ADD THIS
    'comments': comments.map((e) => {'text': e}).toList(),
  };

  String get fullImageUrl => "${ApiEndpoints.baseHost}$image";
}
