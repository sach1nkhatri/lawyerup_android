enum UserStatus {
  firstTime,
  tutorialCompleted,
  loggedIn,
}
